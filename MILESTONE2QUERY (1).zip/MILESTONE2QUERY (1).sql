-- 1
SELECT * 
FROM customer 
WHERE customer_id IN (SELECT customer_id FROM online_booking);

-- 2

SELECT * 
FROM movie 
WHERE director =  "Alfy Hawick";

-- 3

SELECT th.theater_id, t.address, COUNT(th.hall_number) AS total_halls, GROUP_CONCAT(th.hall_type) AS hall_types
FROM theater_hall th
JOIN theater t ON th.theater_id = t.theater_id
GROUP BY th.theater_id;

-- 4

select AVG (total_halls) AS average_halls_per_theater
FROM (SELECT t.theater_id, COUNT(th.hall_number) AS total_halls
 FROM theater t
    LEFT JOIN theater_hall th ON t.theater_id = th.theater_id
      GROUP BY t.theater_id) AS hall_counts;

-- 5

SELECT t.theater_id, t.address, COUNT(th.hall_number) AS total_halls
FROM theater t
LEFT JOIN theater_hall th ON t.theater_id = th.theater_id
GROUP BY t.theater_id;

-- 6 
SELECT MAX(discount_amount) AS max_discount_amount
FROM discount;

-- 7

SELECT c.customer_id, c.customer_first_name, c.customer_last_name, d.ticket_ID
FROM customer c
JOIN online_booking ob ON c.customer_id = ob.customer_id
JOIN ticket t ON ob.ticket_id = t.ticket_id
JOIN discount d ON t.ticket_id = d.ticket_ID;

-- 8


SELECT ta.admin_id, ta.admin_fname, ta.admin_lname, ta.admin_role, t.address, t.number_of_halls
FROM theater_admin ta
INNER JOIN theater t ON ta.theater_id = t.theater_id;

-- 9

SELECT c.customer_id, c.customer_first_name, c.customer_last_name, c.phone_number, c.email
FROM customer c
INNER JOIN online_booking ob ON c.customer_id = ob.customer_id
WHERE DAYOFWEEK(ob.booking_date) IN (1, 7); -- 1 for Sunday, 7 for Saturday

-- 10

SELECT t.theater_id, t.address, t.number_of_halls, ta.admin_fname, ta.admin_lname
FROM theater t
LEFT JOIN theater_admin ta ON t.theater_id = ta.theater_ID;

-- 11

SELECT t.theater_id, t.address, t.number_of_halls, COUNT(ta.admin_id) AS total_administrators
FROM theater t
LEFT JOIN theater_admin ta ON t.theater_id = ta.theater_ID
GROUP BY t.theater_id;

-- 12

SELECT ta.admin_id, ta.admin_fname, ta.admin_lname, ta.admin_role, t.address, t.number_of_halls
FROM theater_admin ta
LEFT JOIN theater t ON ta.theater_ID = t.theater_id;

-- 13

SELECT m.movie_title, COUNT(t.ticket_id) AS tickets_sold
FROM movie m
LEFT JOIN film_time_slot f ON m.movie_id = f.movie_id
LEFT JOIN ticket t ON f.theater_id = t.theater_id AND f.hall_number = t.hall_number
GROUP BY m.movie_title
ORDER BY tickets_sold DESC;

-- 14
SELECT m.movie_title, m.movie_genre
FROM film_time_slot fts
JOIN movie m ON fts.movie_id = m.movie_id
WHERE fts.theater_id = theater_id AND fts.hall_number = hall_number AND fts.date = '2023-06-20' AND fts.start_time = '23:00:14';

-- 15
SELECT movie_title, rating
FROM movie
WHERE rating > 9;

-- 16

SELECT fts.theater_id, fts.hall_number, fts.date, fts.start_time, m.movie_title, m.movie_genre
FROM film_time_slot fts
JOIN movie m ON fts.movie_id = m.movie_id;

-- 17

SELECT movie_title, runtime, director
FROM movie;

-- 18
SELECT SUM(m.runtime) AS total_runtime
FROM film_time_slot fts
JOIN movie m ON fts.movie_id = m.movie_id
WHERE fts.theater_id = theater_id AND fts.date = '2023-06-20';

-- 19

SELECT SUM(price) AS total_price FROM ticket WHERE theater_id = 1;

-- 20

SELECT movie_genre
FROM movie
WHERE rating = (SELECT MAX(rating) FROM movie);

-- 21
select movie_genre, COUNT(movie.movie_genre)
from movie
group by movie_genre;

-- 22

select customer.customer_first_name, customer.customer_last_name, customer.email, movie.movie_title
from movie
join ticket on ticket.movie_id=movie.movie_id
join online_booking on online_booking.ticket_id=ticket.ticket_id
join customer on online_booking.customer_id=customer.customer_id
where movie.rating>9;

-- 23

select featured_movies, count(featured_movies)
from webpage
group by featured_movies
order by count(*) DESC
limit 5;

-- 24

SELECT theater.address
FROM theater
JOIN (
    SELECT theater_id, COUNT(ticket_id) AS ticket_count
    FROM ticket
    GROUP BY theater_id
) AS ticket_counts ON ticket_counts.theater_id = theater.theater_id
WHERE ticket_counts.ticket_count = (
    SELECT MAX(ticket_count) FROM (
        SELECT COUNT(ticket_id) AS ticket_count
        FROM ticket
        GROUP BY theater_id
    ) AS counts
);












